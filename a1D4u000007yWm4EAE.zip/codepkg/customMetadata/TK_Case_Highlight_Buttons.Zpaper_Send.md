<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Send a Fax</label>
    <protected>false</protected>
    <values>
        <field>TK_ComponentName__c</field>
        <value xsi:type="xsd:string">c:TK_Zpaper_VfToLC</value>
    </values>
    <values>
        <field>TK_Object__c</field>
        <value xsi:type="xsd:string">Case</value>
    </values>
    <values>
        <field>TK_Profile_Enabled__c</field>
        <value xsi:type="xsd:string">System Administrator,PSL,PSM,US PM Admin,CC</value>
    </values>
    <values>
        <field>TK_Record_Type_In__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>TK_Record_Type__c</field>
        <value xsi:type="xsd:string">Onboarding,TK_Persistency</value>
    </values>
    <values>
        <field>TK_Sort_Order__c</field>
        <value xsi:type="xsd:double">5.0</value>
    </values>
</CustomMetadata>
